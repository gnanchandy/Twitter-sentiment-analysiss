# Twitter-Sentiment-Analysis
GNR 638 Project


With an aim to make Social Media a Better and Bully free Space, implemented Sentiment Analysis of Twitter tweets using Bag of Words Model, Naive Bayes Model, RNN stacked with LSTM  and CNN LSTM model. CNN-LSTM model gives highest accuracy of 96.1%.
